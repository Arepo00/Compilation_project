"""
MORAD MAROUANE
ABDELLAH HABIBI
SABIR ESSAAD
KAMAL EDDINE BENTOUA

3IIR GRP 4

"""
import re
import ply.lex as lex
import ply.yacc as yacc

tokens = (
    'IDENTIFIER',
    'ASSIGN',
    'SI',
    'ALORS',
    'SINON',
    'FINSI',
    'POUR',
    'DE',
    'JSQ',
    'PAS',
    'FINPOUR',
    'NUMBER',
    'TEXT',
    'TRUE',
    'FALSE',
    'GT',
)

t_ASSIGN = r'='
t_GT = r'>'

t_SI = r'si'
t_ALORS = r'alors'
t_SINON = r'sinon'
t_FINSI = r'finSi'
t_POUR = r'pour'
t_DE = r'de'
t_JSQ = r'jsq'
t_PAS = r'pas'
t_FINPOUR = r'finPour'

def t_IDENTIFIER(t):
    r'[a-z][A-Z0-9]+[A-Z]'
    return t

def t_NUMBER(t):
    r'\d+(\.\d+)?'
    if '.' in t.value:
        t.value = float(t.value)
    else:
        t.value = int(t.value)
    return t

def t_TEXT(t):
    r'\"([^\\\n]|(\\.))*?\"'
    t.value = t.value[1:-1]
    return t

def t_TRUE(t):
    r'vrai'
    t.value = True
    return t

def t_FALSE(t):
    r'faux'
    t.value = False
    return t

def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

t_ignore = ' \t'

def t_error(t):
    t.lexer.skip(1)

lexer = lex.lex()

def nettoyer_commentaires(filename):
    with open(filename, 'r') as file:
        file_content = file.read()

    comment_pattern = re.compile(r'#.*')

    cleaned_content = comment_pattern.sub('', file_content)

    cleaned_filename = filename.replace('.txt', '_cleaned.txt')

    with open(cleaned_filename, 'w') as cleaned_file:
        cleaned_file.write(cleaned_content)

    return cleaned_filename

def analyser_fichier(input_filename, output_filename):
    cleaned_filename = nettoyer_commentaires(input_filename)

    with open(cleaned_filename, 'r') as file:
        code = file.read()

    lexer.input(code)

    with open(output_filename, 'w') as output_file:
        for token in lexer:
            output_file.write(f"{token}\n")

if __name__ == "__main__":
    lecture = input("Le fichier de lecture  : ").lower()
    input_filename = rf"C:\Users\lenovo\Desktop\projet_compilation\Devoir_Compilation_MORAD_HABIBI_ESSAAD_BENTOUA\{lecture}.txt"
    output_filename = rf"C:\Users\lenovo\Desktop\projet_compilation\Devoir_Compilation_MORAD_HABIBI_ESSAAD_BENTOUA\resultat_lexer.txt"
    analyser_fichier(input_filename, output_filename)

#-----------------------------------------------PHASE 3 :-----------------------------------------------#
# Définition des règles de grammaire

def p_programme(p):
    'programme : statements'
    p[0] = p[1]

def p_statements(p):
    '''statements : statement
                  | statements statement'''
    if len(p) == 2:
        p[0] = [p[1]]
    else:
        p[0] = p[1] + [p[2]]

def p_statement_assign(p):
    'statement : IDENTIFIER ASSIGN expression'
    p[0] = ('assign', p[1], p[3])



def p_statement_if(p):
    '''statement : SI condition ALORS statements FINSI
                 | SI condition ALORS statements SINON statements FINSI'''
    if len(p) == 6:
        p[0] = ('if', p[2], p[4])
    else:
        p[0] = ('if-else', p[2], p[4], p[6])

def p_statement_for(p):
    'statement : POUR expression DE expression JSQ expression PAS expression FINPOUR'
    p[0] = ('for', p[2], p[4], p[6], p[8])

def p_condition(p):
    'condition : expression GT expression'
    p[0] = ('gt', p[1], p[3])



def p_expression_identifier(p):
    'expression : IDENTIFIER'
    p[0] = ('identifier', p[1])

def p_expression_number(p):
    'expression : NUMBER'
    p[0] = ('number', p[1])

def p_expression_text(p):
    'expression : TEXT'
    p[0] = ('text', p[1])

def p_expression_boolean(p):
    '''expression : TRUE
                  | FALSE'''
    p[0] = ('boolean', p[1])


def p_error(p):
    if p:
        print(f"Erreur de syntaxe : '{p.value}'")
    else:
        print("Erreur de syntaxe : fin de fichier inattendue")

parser = yacc.yacc(errorlog=lex.NullLogger())

def parse_code(input_file):
    with open(input_file, 'r') as file:
        code = file.read()

    result = parser.parse(code)
    return result

    lecture = input("Le fichier de lecture : ").lower()
    input_filename = rf"C:\Users\lenovo\Desktop\projet_compilation\Devoir_Compilation_MORAD_HABIBI_ESSAAD_BENTOUA\{lecture}.txt"
    syntax_tree = parse_code(input_filename)
    print("Arbre syntaxique :", syntax_tree)
